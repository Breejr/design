package android.example.com.retrofit;

public class Timber  {

    public void timberMe() {
        //Plant Timber for Debug
        if (BuildConfig.DEBUG) {
            timber.log.Timber.plant(new timber.log.Timber.DebugTree());
        } else {
            timber.log.Timber.plant(new ReleaseTree());
        }
    }
}
