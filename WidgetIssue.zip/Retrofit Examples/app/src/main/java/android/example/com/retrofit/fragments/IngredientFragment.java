package android.example.com.retrofit.fragments;

import android.app.ActionBar;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.example.com.retrofit.R;
import android.example.com.retrofit.RecipeWidgetProvider;
import android.example.com.retrofit.adapter.IngredientAdapter;
import android.example.com.retrofit.api.ApiManager;
import android.example.com.retrofit.api.JsonRetrofitApi;
import android.example.com.retrofit.model.Ingredients;
import android.example.com.retrofit.model.Recipe;
import android.os.Bundle;


import android.preference.Preference;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;

import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import timber.log.Timber;


public class IngredientFragment extends Fragment {

  private RecyclerView recyclerView;
  private int id;
  private IngredientAdapter ingredientAdapter;
  private List<Ingredients>ingredientList = null;

  public List allIngredients;
  private Recipe recipes;
  private String title;
  private int page;
  private static FragmentManager fragmentManager;
  private int recipeId;
  private TextView widgetTextView;
  private String fav;
  private SharedPreferences sharedPreferences;
  public static final String FAVORITE = "favorite" ;
  private int appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID;



  public static IngredientFragment newInstance(int page, String title, int recipeId) {

      IngredientFragment ingredientFragment = new IngredientFragment();
      Bundle args = new Bundle();
      args.putInt("1", page);
      args.putString("Title", title);
      args.putInt("recipeId", recipeId);
      ingredientFragment.setArguments(args);

      return ingredientFragment;

  }



    // Store instance variables based on arguments passed
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        page = getArguments().getInt("someInt", 0);
        title = getArguments().getString("someTitle");
        recipeId = getArguments().getInt("recipeId");


    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        sharedPreferences = getActivity().getSharedPreferences(FAVORITE, Context.MODE_PRIVATE);

        Bundle args = getArguments();
        id = args.getInt("recipeId", 0 );

        //Log.e("TITLE", title);

        Toolbar toolbar = getActivity().findViewById(R.id.toolbar); // get the reference of Toolbar
        Button addToWidget = getActivity().findViewById(R.id.widget_button); // get reference to add to widget button

        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.recycleview_ingredient, container, false);

        recyclerView = rootView.findViewById(R.id.recycler_view_ingredient);
        recyclerView.setHasFixedSize(true);

        RecyclerView.LayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(linearLayoutManager);

        getIngredients();


        //Click Listener for Widget

        addToWidget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                Recipe recipes = new Recipe(0, "");
                String widgetName = recipes.getName();


                //Initalize Shared Preference Editor and save information
                SharedPreferences.Editor editor = sharedPreferences.edit();
                //Send Retrofit Response to Favorites
                editor.putString("Favorites", fav);
                editor.putString("WidgetName", widgetName);
                Log.e("SHARED PREFERENCE", fav);

                //What do I need to put in here to send information to my widget?

            }
        });

        return rootView;


    }



        public void getIngredients() {


        JsonRetrofitApi jsonRetrofitApi = ApiManager.getClient();

        Call<List<Recipe>> call = jsonRetrofitApi.getRecipes();

        call.enqueue(new Callback<List<Recipe>>() {
            @Override
            public void onResponse(Call<List<Recipe>> call, Response<List<Recipe>> response) {

                if (!response.isSuccessful()) {

                    return;
                }

                Timber.d("Retrofit Ingredients Success");
                Gson gson = new Gson();
                List<Recipe> jsonResponse = response.body();
                //String to save to Shared Preferences on favorite
                fav = gson.toJson(response.body());
                generateList(jsonResponse);

            }

            @Override
            public void onFailure(Call<List<Recipe>> call, Throwable t) {
                Timber.d("Retrofit Ingredients Failed");

            }
        });
    }

    private void generateList(List<Recipe> jsonResponse) {

        Recipe recipe = null;

        for (Recipe r: jsonResponse) {
            if ((r.getId()==id)) {
                recipe = r;
                break;
            }
        }

        if (recipe == null) {
            return;
        } else {
            ingredientAdapter = new IngredientAdapter(getContext(), recipe.getIngredients());
            recyclerView.setAdapter(ingredientAdapter);
            Timber.d("Ingredients Adapter Attached");

        }

    }





}
