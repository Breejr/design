package android.example.com.retrofit.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.TextViewCompat;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager.widget.PagerTabStrip;
import androidx.viewpager.widget.ViewPager;

import android.app.ActionBar;
import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.example.com.retrofit.BuildConfig;
import android.example.com.retrofit.RecipeWidgetProvider;
import android.example.com.retrofit.ReleaseTree;
import android.example.com.retrofit.adapter.FragmentPagerAdapter;
import android.example.com.retrofit.R;
import android.example.com.retrofit.fragments.IngredientFragment;
import android.example.com.retrofit.fragments.StepDetailsFragment;
import android.example.com.retrofit.fragments.StepsFragment;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;


import timber.log.Timber;

public class IngredientActivity extends AppCompatActivity {

    private int id;
    private FragmentManager fragmentManager;
    FragmentPagerAdapter adapterViewPager;
    private TextView firstTextView;
    private TextView secondTextView;
    private TextView thirdTextView;
    private PagerTabStrip pagerTabStrip;
    private boolean twoPane;
    private int orientation;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingredient);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar); // get the reference of Toolbar
        Button addToWidget = findViewById(R.id.widget_button); // get reference to add to widget button

        //Add Custom toolbar with widget button
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.toolbar);

        //Grab recipe ID from intent
        Intent intent = getIntent();

        id = intent.getIntExtra("recipeId", 0);

        //Plant Timber for Debug
        if (BuildConfig.DEBUG) {
            Timber.plant(new Timber.DebugTree());
        } else {
            Timber.plant(new ReleaseTree());
        }

        //Set to Tablet
        if(getResources().getBoolean(R.bool.isTab)) {
            Timber.e("TABLET");
            twoPane = true;
            Timber.e(String.valueOf(twoPane));

        //Set to Mobile
        } else {
            Timber.e("PHONE");
            Timber.e(String.valueOf(twoPane));
            twoPane = false;
        }


        //Find the views for the title bar
        firstTextView = findViewById(R.id.firstTextView);
        secondTextView = findViewById(R.id.secondTextView);
        thirdTextView = findViewById(R.id.thirdTextView);

        //Set Text appearance for header
        TextViewCompat.setTextAppearance(firstTextView,R.style.RecyclerViewOutput);
        TextViewCompat.setTextAppearance(secondTextView,R.style.RecyclerViewOutput);
        TextViewCompat.setTextAppearance(thirdTextView,R.style.RecyclerViewOutput);

        //Find ViewPager and adapter
        final ViewPager viewPager = findViewById(R.id.viewPager);
        adapterViewPager = new FragmentPagerAdapter(getSupportFragmentManager());
        viewPager.setAdapter(adapterViewPager);

        //Default view Ingredient Fragment
        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.fragment_content, IngredientFragment.newInstance(1, "Ingredients", id))
                .commit();


        //Stylize ViewPager Strip
        pagerTabStrip = findViewById(R.id.pager_header);
        pagerTabStrip.setTabIndicatorColor(Color.WHITE);
        pagerTabStrip.setTextColor(Color.WHITE);


        // Attach the page change listener inside the activity
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {

            // This method will be invoked when a new page becomes selected.
            @Override
            public void onPageSelected(int position) {
                Toast.makeText(IngredientActivity.this,
                        "Selected page position: " + position, Toast.LENGTH_SHORT).show();

                adapterViewPager.notifyChangeInPosition(1);
                adapterViewPager.notifyDataSetChanged();

                //IF ViewPager slider is on Ingredients, show the following fragment:
                if (position == 0) {

                    firstTextView.setText("Size:");
                    secondTextView.setText("Measure");
                    thirdTextView.setText("Ingredient");


                    //If we have  a tablet, and we swipe to position 0 (Ingredients) We remove the old fragment from Steps and create a new Ingredient Fragment
                    if (twoPane) {
                        //Fragment Transaction
                        fragmentManager = getSupportFragmentManager();
                        fragmentManager.beginTransaction()
                                .replace(R.id.fragment_content, IngredientFragment.newInstance(1, "Test", id))
                                .remove(getSupportFragmentManager().findFragmentById(R.id.exoplayer_content))
                                .commit();


                        //If device is a tablet and swipes back to Ingredients list, change size of fragment
                        FrameLayout frameLayout = findViewById(R.id.fragment_content);
                        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
                        frameLayout.setLayoutParams(params);

                    }

                    //If we do not have a tablet when we swip to position 0, standard simple view
                    if (!twoPane) {
                        singleViewIngredients();
                    }

                    //If ViewPager slider is on position 1 Steps, show the following fragment
                } else if (position == 1) {

                    //If not a tablet, show the following fragment from StepsFragment
                    if (!twoPane) {
                        singleViewSteps();
                    }

                    //If we have a tablet, and orientation is landscape
                    else if (twoPane && orientation==1) {

                        tabletModeSideBySide();

                    }
                    //Anything else show original single layout fragment
                    else {
                        singleViewIngredients();
                    }

                }

            }

            // This method will be invoked when the current page is scrolled
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                // Code goes here
            }

            // Called when the scroll state changes:
            // SCROLL_STATE_IDLE, SCROLL_STATE_DRAGGING, SCROLL_STATE_SETTLING
            @Override
            public void onPageScrollStateChanged(int state) {
                // Code goes here
            }
        });

    }

    @Override
    public void onResume() {

        //Get Screen Orientation

        orientation = getResources().getConfiguration().orientation;

        if(orientation == Configuration.ORIENTATION_LANDSCAPE) {
            //Screen is in landscape mode
            Timber.e("LANDSCAPE MODE");
            orientation = 1;

            //If device orientation changes to landscape and we have a tablet, activate side by side mode
            if (twoPane && orientation==1) {
                tabletModeSideBySide();
            }


        } else {

            //Screen is in portrait mode
            orientation = 0;
            Timber.e("PORTRAIT MODE");

            //If device is a tablet and rotates back to portrait mode, change frame layout size
            FrameLayout frameLayout = findViewById(R.id.fragment_content);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
            frameLayout.setLayoutParams(params);
        }
        super.onResume();
    }

    public void tabletModeSideBySide() {

        firstTextView.setText("Title");
        secondTextView.setText("Description");
        thirdTextView.setText("Video");

        //Fragment Transaction
        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.fragment_content, StepsFragment.newInstance(1, "Test", id))
                .commit();

        adapterViewPager.notifyDataSetChanged();

        //Convert to DP
        final float scale = getResources().getDisplayMetrics().density;
        int dpwidth = (int) (600 * scale);

        //If device is in landscape mode and is a tablet, change size of fragment
        FrameLayout frameLayout = findViewById(R.id.fragment_content);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dpwidth, LinearLayout.LayoutParams.MATCH_PARENT);
        frameLayout.setLayoutParams(params);


        //Fragment Transaction
        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.exoplayer_content, StepDetailsFragment.newInstance(1, "Test", id, ""))
                .commit();

        adapterViewPager.notifyDataSetChanged();


    }

    public void singleViewSteps() {

        firstTextView.setText("Title");
        secondTextView.setText("Description");
        thirdTextView.setText("Video");


        //Fragment Transaction
        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.fragment_content, StepsFragment.newInstance(1, "Test", id))
                .commit();

        adapterViewPager.notifyDataSetChanged();

    }

    public void singleViewIngredients() {

        firstTextView.setText("Title");
        secondTextView.setText("Description");
        thirdTextView.setText("Video");


        //Fragment Transaction
        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.fragment_content, IngredientFragment.newInstance(1, "Test", id))
                .commit();

        adapterViewPager.notifyDataSetChanged();

    }


}
