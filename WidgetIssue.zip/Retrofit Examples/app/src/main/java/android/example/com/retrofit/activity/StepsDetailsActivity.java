package android.example.com.retrofit.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.example.com.retrofit.R;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.PlaybackParameters;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.Timeline;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.TrackGroupArray;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelectionArray;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.util.Util;


public class StepsDetailsActivity extends AppCompatActivity  {

    private String videoUrl;
    PlayerView playerView;
    private ExoPlayer exoPlayer;
    private long lastPosition = 0;
    private boolean playBackStatus;
    private String videoTitle;
    private TextView videoTitleTV;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_steps);

        Intent intent = getIntent();
        videoUrl = intent.getStringExtra("videoUrl");
        videoTitle = intent.getStringExtra("shortDescription");

        videoTitleTV = findViewById(R.id.video_title);

        videoTitleTV.setText(videoTitle);


        Log.e("VIDEO URL", videoUrl);
        playerView = findViewById(R.id.playerView);

        //For device orientation changes
        if (savedInstanceState !=null) {
            //save the last viewed position
            lastPosition = savedInstanceState.getLong("lastPosition", 0);

            playBackStatus = savedInstanceState.getBoolean("ready", false);
        }



    }


    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putLong("lastPosition", lastPosition);
        outState.putBoolean("playbackReady", playBackStatus);
    }

    @Override
    public void onResume() {
        super.onResume();

        playerView = findViewById(R.id.playerView);

        exoPlayer = ExoPlayerFactory.newSimpleInstance(this, new DefaultTrackSelector());

        //Sets the exoplayer view
        playerView.setPlayer(exoPlayer);

        DefaultDataSourceFactory dataSourceFactory = new DefaultDataSourceFactory(this, Util.getUserAgent(this, "BakingApp"));

        // parse video URL
        ExtractorMediaSource extractorMediaSource = new ExtractorMediaSource.Factory(dataSourceFactory).createMediaSource(Uri.parse(videoUrl));

        //Prepare exoplayer to start buffer
        exoPlayer.prepare(extractorMediaSource);
        //Set player to last viewed position
        exoPlayer.seekTo(lastPosition);

        exoPlayer.addListener(new Player.EventListener() {
            @Override
            public void onTimelineChanged(Timeline timeline, Object manifest, int reason) {
            }

            @Override
            public void onTracksChanged(TrackGroupArray trackGroups, TrackSelectionArray trackSelections) {
            }

            @Override
            public void onLoadingChanged(boolean isLoading) {
            }

            @Override
            public void onPlayerStateChanged(boolean playWhenReady, int playbackState) {

            }

            @Override
            public void onRepeatModeChanged(int repeatMode) {
            }

            @Override
            public void onShuffleModeEnabledChanged(boolean shuffleModeEnabled) {
            }

            @Override
            public void onPlayerError(ExoPlaybackException error) {
            }

            @Override
            public void onPositionDiscontinuity(int reason) {
            }

            @Override
            public void onPlaybackParametersChanged(PlaybackParameters playbackParameters) {
            }

            @Override
            public void onSeekProcessed() {
            }
        });

        exoPlayer.setPlayWhenReady(playBackStatus);
    }

    @Override
    public void onPause() {
        saveExoPlayerState();
        //Release ExoPlayer
        releaseExoPlayer();

        super.onPause();
    }

    private void saveExoPlayerState() {
        //Get the last viewed position
        lastPosition = exoPlayer.getCurrentPosition();
        playBackStatus = exoPlayer.getPlayWhenReady();
    }

    private void releaseExoPlayer() {
        playerView.setPlayer(null);
        exoPlayer.release();
        exoPlayer = null;
    }


}
