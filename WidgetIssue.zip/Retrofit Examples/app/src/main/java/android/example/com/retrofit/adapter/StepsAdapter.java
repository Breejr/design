package android.example.com.retrofit.adapter;

import android.content.Context;
import android.content.Intent;
import android.example.com.retrofit.BuildConfig;
import android.example.com.retrofit.R;
import android.example.com.retrofit.ReleaseTree;
import android.example.com.retrofit.activity.StepsDetailsActivity;
import android.example.com.retrofit.fragments.StepDetailsFragment;
import android.example.com.retrofit.model.Steps;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import timber.log.Timber;

public class StepsAdapter extends RecyclerView.Adapter<StepsAdapter.CustomViewHolder> {

    private Context mContext;
    private List<Steps> mSteps;
    private boolean twoPane;
    private int orientation;


    public StepsAdapter(Context context, List<Steps> steps, boolean twoPane, int orientation) {
        mContext = context;
        mSteps = steps;
        this.twoPane = twoPane;
        this.orientation = orientation;
    }



    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        //Plant Timber for Debug
        if (BuildConfig.DEBUG) {
            Timber.plant(new Timber.DebugTree());
        } else {
            Timber.plant(new ReleaseTree());
        }

        Timber.e(String.valueOf(twoPane));

        //If tablet and orientation is landscape
        if (twoPane == true && orientation ==1) {
            View v = LayoutInflater.from(mContext).inflate(R.layout.card_view_steps, parent, false);
            Timber.e("card_view_steps_twopane Inflated");



            return new CustomViewHolder(v);
            //If no tablet or orientation is portrait
        }

            else {

                View v = LayoutInflater.from(mContext).inflate(R.layout.card_view_steps, parent, false);
                return new CustomViewHolder(v);
        }

    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {

        //If adapter is  NOT a tablet, use the following

        final Steps currentRecipe = mSteps.get(position);

        final int stepID = currentRecipe.getId();
        final String shortDescription = currentRecipe.getShortDescription();
        final String videoUrl = currentRecipe.getVideoURL();
        //String thumbnailUrl = currentRecipe.getThumbnailURL();
        final String description = currentRecipe.getDescription();

        //holder.stepIdTV.setText(Integer.toString(stepID + 1) + ".");
        holder.shortDescriptionTV.setText(shortDescription);
        holder.longDescriptionTV.setText(description);
        holder.videoUrlTV.setText(videoUrl);
        //holder.thumbnailUrlTV.setText(thumbnailUrl);

        //Set Visibility for clean UI
        if (shortDescription.equalsIgnoreCase(description)) {
            holder.longDescriptionTV.setText("");
            holder.longDescriptionTV.setVisibility(View.GONE);
        } else if (!shortDescription.equalsIgnoreCase(description)) {
            holder.longDescriptionTV.setText(description);
        }

        if (!videoUrl.isEmpty()) {

            holder.videoIV.setVisibility(View.VISIBLE);
            holder.videoUrlTV.setText("Play Video");

        } else {
            holder.videoIV.setVisibility(View.GONE);
            holder.videoUrlTV.setVisibility(View.GONE);
        }

/*        if (thumbnailUrl.isEmpty()) {
            holder.thumbnailUrlTV.setVisibility(View.GONE);
        }*/

        //Click Listener for Recipe Cards
        //If video URL is not empty, allows clicking to view video

        if (orientation == 0) {
            holder.mCardView.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View view) {

                    if (!videoUrl.equalsIgnoreCase("")) {
                        Intent mIntent = new Intent(mContext, StepsDetailsActivity.class);
                        mIntent.putExtra("videoUrl", videoUrl);
                        mIntent.putExtra("description", description);
                        mIntent.putExtra("shortDescription", shortDescription);

                        mContext.startActivity(mIntent);
                    }
                }
            });

        }

        //If tablet and orientation is landscape
        if (twoPane && orientation == 1) {
                holder.mCardView.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View view) {

                        if (!videoUrl.equalsIgnoreCase("")) {

                            Timber.e("Tablet click listener activated");

                            Fragment fragment = StepDetailsFragment.newInstance(currentRecipe.getId(), currentRecipe.getDescription(), currentRecipe.getId(), currentRecipe.getVideoURL());
                            FragmentManager fm = ((AppCompatActivity)mContext).getSupportFragmentManager();
                            FragmentTransaction ft = fm.beginTransaction();
                            ft.replace(R.id.playerview_twopane2, fragment);
                            ft.commit();

                        }
                    }

                });
        }
    }




    @Override
    public int getItemCount() {

        return mSteps.size();
    }


    public class CustomViewHolder extends RecyclerView.ViewHolder {

        public TextView stepIdTV;
        public TextView shortDescriptionTV;
        public TextView videoUrlTV;
        //public TextView thumbnailUrlTV;
        public CardView mCardView;
        public TextView longDescriptionTV;
        public ImageView videoIV;
        //public CardView cardViewTablet;


        public CustomViewHolder(View itemView) {
            super(itemView);

            //stepIdTV = itemView.findViewById(R.id.id_fragment);
            shortDescriptionTV = itemView.findViewById(R.id.shortdescription_fragment);
            videoUrlTV = itemView.findViewById(R.id.video_url);
            //thumbnailUrlTV = itemView.findViewById(R.id.thumbnail_fragment);
            longDescriptionTV = itemView.findViewById(R.id.long_description_fragment);
            mCardView = itemView.findViewById(R.id.card_view_steps);
            videoIV = itemView.findViewById(R.id.video_icon);
            //cardViewTablet = itemView.findViewById(R.id.card_view_steps);
        }

    }


}