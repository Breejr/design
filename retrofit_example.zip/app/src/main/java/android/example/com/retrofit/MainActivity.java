package android.example.com.retrofit;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.example.com.retrofit.api.JsonRetrofitApi;
import android.example.com.retrofit.model.Recipe;
import android.os.Bundle;
import android.util.Log;
import android.widget.GridLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private TextView textViewResult;
    private ArrayList<Recipe> recipeArrayList;
    private MainAdapter mainAdapter;
    private RecyclerView recyclerView;
    private Recipe recipe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //textViewResult = findViewById(R.id.text_view_result);


        getRecipes();

    }

       public void getRecipes() {

        recipeArrayList = new ArrayList<>();
        recipe = new Recipe(0, "");

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://d17h27t6h515a5.cloudfront.net/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        JsonRetrofitApi jsonRetrofitApi = retrofit.create(JsonRetrofitApi.class);

        Call<List<Recipe>> call = jsonRetrofitApi.getRecipes();

        call.enqueue(new Callback<List<Recipe>>() {
            @Override
            public void onResponse(Call<List<Recipe>> call, Response<List<Recipe>> response) {

                if (!response.isSuccessful()) {

                    textViewResult.setText("Code: " + response.code());

                    return;
                }

                List<Recipe> jsonResponse = response.body();
                generateList(jsonResponse);

            }

            @Override
            public void onFailure(Call<List<Recipe>> call, Throwable t) {

                textViewResult.setText(t.getMessage());
            }
        });

    }

    private void generateList(List jsonResponse) {

        recyclerView = findViewById(R.id.recycler_view_main);
        recyclerView.setHasFixedSize(true);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(MainActivity.this, 2);
        recyclerView.setLayoutManager(gridLayoutManager);
        recipeArrayList = new ArrayList<>();

        Log.e("RECIPE SIZE", String.valueOf(jsonResponse.size()));

        mainAdapter = new MainAdapter(this, jsonResponse);
        recyclerView.setAdapter(mainAdapter);



    }


}
