package android.example.com.retrofit.api;

import android.example.com.retrofit.model.Recipe;
import android.widget.TextView;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiManager {

    private TextView textView;

/*    public void getRecipes() {



        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://d17h27t6h515a5.cloudfront.net/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        JsonRetrofitApi jsonRetrofitApi = retrofit.create(JsonRetrofitApi.class);

        Call<List<Recipe>> call = jsonRetrofitApi.getPosts();

        call.enqueue(new Callback<List<Recipe>>() {
            @Override
            public void onResponse(Call<List<Recipe>> call, Response<List<Recipe>> response) {

                if (!response.isSuccessful()) {

                    textViewResult.setText("Code: " + response.code());
                    return;
                }

                List<Recipe> recipes = response.body();

                for (Recipe recipe : recipes) {

                    String content = "";
                    content += "ID: " + recipe.getId() + "\n";
                    content +="NAME: " + recipe.getName() + "\n";

                    textViewResult.append(content);
                }

            }

            @Override
            public void onFailure(Call<List<Recipe>> call, Throwable t) {

                textViewResult.setText(t.getMessage());
            }
        });

    }*/
}
