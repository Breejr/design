package android.example.com.retrofit;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.example.com.retrofit.api.JsonRetrofitApi;
import android.example.com.retrofit.model.Ingredients;
import android.example.com.retrofit.model.Recipe;
import android.os.Bundle;
import android.util.Log;

import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class IngredientActivity extends AppCompatActivity {

    private int id;
    private ArrayList<Ingredients> ingredientsArrayList;
    private Ingredients ingredients;
    private RecyclerView recyclerView;
    private IngredientAdapter ingredientAdapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingredient);


        Intent intent = getIntent();

        id = intent.getIntExtra("recipeId", 0);

        getIngredients();

    }


    public void getIngredients() {

        ingredientsArrayList = new ArrayList<>();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://d17h27t6h515a5.cloudfront.net/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        JsonRetrofitApi jsonRetrofitApi = retrofit.create(JsonRetrofitApi.class);

        Call<List<Ingredients>> call = jsonRetrofitApi.getIngredients();

        call.enqueue(new Callback<List<Ingredients>>() {
            @Override
            public void onResponse(Call<List<Ingredients>> call, Response<List<Ingredients>> response) {

                if (!response.isSuccessful()) {

                    Log.e("SUCCESS", "SUCCESS");

                    return;
                }

                List<Ingredients> jsonResponse = response.body();
                Log.e("TAG", String.valueOf(jsonResponse));
                generateList(jsonResponse);

            }

            @Override
            public void onFailure(Call<List<Ingredients>> call, Throwable t) {

                Log.e("FAIL", "FAIL");
                //textViewResult.setText(t.getMessage());
            }
        });


    }

    private void generateList(List jsonResponse) {

        recyclerView = findViewById(R.id.recycler_view_ingredient);
        recyclerView.setHasFixedSize(true);

        RecyclerView.LayoutManager linearLayoutManager = new LinearLayoutManager(IngredientActivity.this);
        recyclerView.setLayoutManager(linearLayoutManager);

        Log.e("JSON RESPONSE", String.valueOf(jsonResponse));
        Log.e("RECIPE SIZE", String.valueOf(jsonResponse.size()));

        ingredientAdapter = new IngredientAdapter(this, jsonResponse);
        recyclerView.setAdapter(ingredientAdapter);



    }



}
