package android.example.com.javajokeslibrary;

import com.sun.corba.se.spi.activation.BadServerDefinition;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import sun.rmi.runtime.Log;


public class JavaJokes {


    //http://www.devtopics.com/best-programming-jokes/
    //https://devdojo.com/articles/10-awesome-programming-jokes



    public static String getJokes() {

    ArrayList<String> jokes = new ArrayList<>();

    jokes.add("Knock, knock. \n" +
                    "Who's there? \n" +
                    "[Very long pause...]\n" +
                    "Java");
    jokes.add("I just saw my life flash before my eyes and all I could see was a close tag.");
    jokes.add("Q. How did the programmer die in the shower? \n" +
            "A. He read the shampoo bottle instructions: Lather. Rinse. Repeat.");
    jokes.add("There are only 10 kinds of people in this world: those who know binary and those who don't.");
    jokes.add("How many programmers does it take to change a light bulb?\n" +
            "None, It’s a hardware problem");
    jokes.add("The generation of random numbers is too important to be left to chance.");
    jokes.add("Q: Why did the programmer quit his job?\n" +
            "\n" +
            "A: Because he didn't get arrays.");
    jokes.add("Q: What did the Java code say to the C code?\n" +
            "\n" +
            "A: You've got no class.");
    jokes.add("Q: \"Whats the object-oriented way to become wealthy?\"\n" +
            "\n" +
            "A: Inheritance");




    int arraySize = jokes.size();
    Random random = new Random();
    int rand = random.nextInt(arraySize);

    String randomJoke = jokes.get(rand);
    return  randomJoke;


    }



}
