package android.example.com.retrofit.adapter;

import android.example.com.retrofit.activity.IngredientActivity;
import android.example.com.retrofit.fragments.IngredientFragment;
import android.example.com.retrofit.fragments.StepsFragment;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class FragmentPagerAdapter extends androidx.fragment.app.FragmentPagerAdapter {

    private static int NUM_ITEMS = 2;
    private int baseID = 0;

    public FragmentPagerAdapter(FragmentManager fragmentManager) {
        super(fragmentManager, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position) {

            case 0: //Fragment 0 shows the first Fragment
                Log.e("TEST", "TEST!!!");

                return IngredientFragment.newInstance(0, "Ingredients", 0);

            case 1: //Fragment 1 shows second fragment
                return StepsFragment.newInstance(1, "Steps", 0);

            default:
                return null;
        }
    }

    @Override
    public CharSequence getPageTitle(int position) {

        if (position == 0) {
            return "Ingredients";
        } else {
            return "Steps";
        }


    }

    @Override
    public int getItemPosition(Object object) {

        //refresh fragments when data set changes
        return FragmentPagerAdapter.POSITION_NONE;

    }

    public void notifyChangeInPosition(int n) {

        baseID += getCount() + n;
    }



    @Override
    public int getCount() {
        return NUM_ITEMS;
    }




}


