package android.example.com.retrofit.fragments;

import android.content.res.Configuration;
import android.example.com.retrofit.BuildConfig;
import android.example.com.retrofit.R;
import android.example.com.retrofit.ReleaseTree;
import android.example.com.retrofit.adapter.StepsAdapter;
import android.example.com.retrofit.api.ApiManager;
import android.example.com.retrofit.api.JsonRetrofitApi;
import android.example.com.retrofit.model.Recipe;
import android.example.com.retrofit.model.Steps;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import timber.log.Timber;


public class StepsFragment extends Fragment {

    private String title;
    private int page;
    private RecyclerView recyclerView;
    private int id;
    private StepsAdapter stepsAdapter;
    private int recipeId;
    private boolean twoPane;
    private LinearLayout linearLayout;
    private int orientation;

    public static StepsFragment newInstance(int page, String title, int recipeId) {

        StepsFragment stepsFragment = new StepsFragment();
        Bundle args = new Bundle();
        args.putInt("1", page);
        args.putString("Title", title);
        args.putInt("recipeId", recipeId);
        stepsFragment.setArguments(args);
        return stepsFragment;

    }

    // Store instance variables based on arguments passed
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        page = getArguments().getInt("someInt", 0);
        title = getArguments().getString("someTitle");
        recipeId = getArguments().getInt("recipeId", 0);

        //Plant Timber for Debug
        if (BuildConfig.DEBUG) {
            Timber.plant(new Timber.DebugTree());
        } else {
            Timber.plant(new ReleaseTree());
        }

        //Set Tablet Version
        if(getResources().getBoolean(R.bool.isTab)) {
            Timber.e("TABLET");
            twoPane = true;
            Timber.e(String.valueOf(twoPane));

        } else {
            Timber.e("PHONE");
            Timber.e(String.valueOf(twoPane));
            twoPane = false;
        }




    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        Bundle args = getArguments();
        id = args.getInt("recipeId", 0 );


        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.recycleview_steps, container, false);


        recyclerView = rootView.findViewById(R.id.recycler_view_steps);
        recyclerView.setHasFixedSize(true);

        RecyclerView.LayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(linearLayoutManager);

        getSteps();

        return rootView;


    }

    public void getSteps() {


        JsonRetrofitApi jsonRetrofitApi = ApiManager.getClient();

        Call<List<Recipe>> call = jsonRetrofitApi.getRecipes();

        call.enqueue(new Callback<List<Recipe>>() {
            @Override
            public void onResponse(Call<List<Recipe>> call, Response<List<Recipe>> response) {

                if (!response.isSuccessful()) {

                    Log.e("isSuccessful","FAILED");
                    return;
                }


                List<Recipe> jsonResponse = response.body();
                generateList(jsonResponse);
                Timber.d("Retrofit Steps Success");

            }

            @Override
            public void onFailure(Call<List<Recipe>> call, Throwable t) {
                Timber.d("Retrofit Steps Failed");

            }
        });
    }

    private void generateList(List<Recipe> jsonResponse) {

        Recipe recipe = null;

        for (Recipe r: jsonResponse) {
            if ((r.getId()==id)) {
                recipe = r;
                break;
            }
        }


        if (recipe == null) {
            return;
        } else {
            stepsAdapter = new StepsAdapter(getContext(), recipe.getSteps(), twoPane, orientation);
            recyclerView.setAdapter(stepsAdapter);
            Timber.d("Steps Adapter Attached");


        }

    }

    @Override
    public void onResume() {

        //Get Screen Orientation

        orientation = getResources().getConfiguration().orientation;

        if(orientation == Configuration.ORIENTATION_LANDSCAPE) {
            //Screen is in landscape mode
            Timber.e("LANDSCAPE MODE");
            orientation = 1;

        } else {

            //Screen is in portrait mode
            orientation = 0;
            Timber.e("PORTRAIT MODE");
        }
        super.onResume();
    }
}
