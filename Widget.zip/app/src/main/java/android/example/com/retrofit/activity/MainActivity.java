package android.example.com.retrofit.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ActionBar;
import android.example.com.retrofit.adapter.MainAdapter;
import android.example.com.retrofit.R;
import android.example.com.retrofit.api.ApiManager;
import android.example.com.retrofit.api.JsonRetrofitApi;
import android.example.com.retrofit.model.Recipe;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toolbar;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import timber.log.Timber;

public class MainActivity extends AppCompatActivity {

    private TextView textViewResult;
    private ArrayList<Recipe> recipeArrayList;
    private MainAdapter mainAdapter;
    private RecyclerView recyclerView;
    private Recipe recipe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        getRecipes();

    }

       public void getRecipes() {

        recipeArrayList = new ArrayList<>();
        recipe = new Recipe(0, "");

        JsonRetrofitApi jsonRetrofitApi = ApiManager.getClient();

        Call<List<Recipe>> call = jsonRetrofitApi.getRecipes();

        call.enqueue(new Callback<List<Recipe>>() {
            @Override
            public void onResponse(Call<List<Recipe>> call, Response<List<Recipe>> response) {

                if (!response.isSuccessful()) {

                    textViewResult.setText("Code: " + response.code());

                    return;
                }

                Timber.d("Retrofit MainActivity Success");
                List<Recipe> jsonResponse = response.body();
                generateList(jsonResponse);

            }

            @Override
            public void onFailure(Call<List<Recipe>> call, Throwable t) {

                Timber.d("Retrofit MainActivity Failed");
            }
        });

    }

    private void generateList(List jsonResponse) {

        recyclerView = findViewById(R.id.recycler_view_main);
        recyclerView.setHasFixedSize(true);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(MainActivity.this, 2);


        recyclerView.setLayoutManager(gridLayoutManager);
        recipeArrayList = new ArrayList<>();


        Log.e("RECIPE SIZE", String.valueOf(jsonResponse.size()));

        mainAdapter = new MainAdapter(this, jsonResponse);
        recyclerView.setAdapter(mainAdapter);
        Timber.d(" MainActivity Adapter Attached");


    }



}
