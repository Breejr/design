package android.example.com.retrofit.fragments;

import android.content.Intent;
import android.content.res.Configuration;
import android.example.com.retrofit.BuildConfig;
import android.example.com.retrofit.R;
import android.example.com.retrofit.ReleaseTree;
import android.example.com.retrofit.adapter.IngredientAdapter;
import android.example.com.retrofit.adapter.StepsAdapter;
import android.example.com.retrofit.api.ApiManager;
import android.example.com.retrofit.api.JsonRetrofitApi;
import android.example.com.retrofit.model.Ingredients;
import android.example.com.retrofit.model.Recipe;
import android.example.com.retrofit.model.Steps;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.PlaybackParameters;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.Timeline;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.TrackGroupArray;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelectionArray;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.util.Util;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import timber.log.Timber;

public class StepDetailsFragment extends Fragment {


    PlayerView playerView;
    private ExoPlayer exoPlayer;
    private long lastPosition = 0;
    private boolean playBackStatus;
    private int page;
    private String title;
    private int recipeId;
    private String videoUrl;
    private Steps steps;
    private Timber timber;
    private int id;
    private StepsAdapter stepsAdapter;
    private RecyclerView recyclerView;
    private boolean twoPane;
    private int orientation;


    public static StepDetailsFragment newInstance(int page, String title, int recipeId, String videoUrl) {

        StepDetailsFragment stepDetailsFragment = new StepDetailsFragment();
        Bundle args = new Bundle();
        args.putInt("1", page);
        args.putString("Title", title);
        args.putInt("recipeId", recipeId);
        args.putString("videoUrl", videoUrl);
        stepDetailsFragment.setArguments(args);

        return stepDetailsFragment;

    }



    // Store instance variables based on arguments passed
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        page = getArguments().getInt("someInt", 0);
        title = getArguments().getString("someTitle");
        recipeId = getArguments().getInt("recipeId");


        //Plant Timber for Debug
        if (BuildConfig.DEBUG) {
            Timber.plant(new Timber.DebugTree());
        } else {
            Timber.plant(new ReleaseTree());
        }


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        Bundle args = getArguments();
        id = args.getInt("recipeId", 0);
        videoUrl = getArguments().getString("videoUrl");
        View rootView = inflater.inflate(R.layout.exoplayer_fragment, container, false);
        exoPlayer = ExoPlayerFactory.newSimpleInstance(getContext(), new DefaultTrackSelector());

        playerView = rootView.findViewById(R.id.playerview_twopane2);
        //Sets the exoplayer view
        playerView.setPlayer(exoPlayer);

        onResume();

        return rootView;


    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putLong("lastPosition", lastPosition);
        outState.putBoolean("playbackReady", playBackStatus);
    }

    @Override
    public void onResume() {
        super.onResume();

        exoPlayer = ExoPlayerFactory.newSimpleInstance(getContext(), new DefaultTrackSelector());

        //Sets the exoplayer view
        playerView.setPlayer(exoPlayer);

        DefaultDataSourceFactory dataSourceFactory = new DefaultDataSourceFactory(getContext(), "BakingApp");


        // parse video URL
        ExtractorMediaSource extractorMediaSource = new ExtractorMediaSource.Factory(dataSourceFactory).createMediaSource(Uri.parse(videoUrl));

        //Prepare exoplayer to start buffer
        exoPlayer.prepare(extractorMediaSource);
        //Set player to last viewed position
        exoPlayer.seekTo(lastPosition);

        //Get Screen Orientation

        orientation = getResources().getConfiguration().orientation;

        if(orientation == Configuration.ORIENTATION_LANDSCAPE) {
            //Screen is in landscape mode
            Timber.e("LANDSCAPE MODE");
            orientation = 1;

        } else {

            //Screen is in portrait mode
            orientation = 0;
            Timber.e("PORTRAIT MODE");
        }

        exoPlayer.addListener(new Player.EventListener() {
            @Override
            public void onTimelineChanged(Timeline timeline, Object manifest, int reason) {
            }

            @Override
            public void onTracksChanged(TrackGroupArray trackGroups, TrackSelectionArray trackSelections) {
            }

            @Override
            public void onLoadingChanged(boolean isLoading) {
            }

            @Override
            public void onPlayerStateChanged(boolean playWhenReady, int playbackState) {

            }

            @Override
            public void onRepeatModeChanged(int repeatMode) {
            }

            @Override
            public void onShuffleModeEnabledChanged(boolean shuffleModeEnabled) {
            }

            @Override
            public void onPlayerError(ExoPlaybackException error) {
            }

            @Override
            public void onPositionDiscontinuity(int reason) {
            }

            @Override
            public void onPlaybackParametersChanged(PlaybackParameters playbackParameters) {
            }

            @Override
            public void onSeekProcessed() {
            }
        });

        exoPlayer.setPlayWhenReady(playBackStatus);
    }

    @Override
    public void onPause() {
        saveExoPlayerState();
        //Release ExoPlayer
        releaseExoPlayer();

        super.onPause();
    }

    private void saveExoPlayerState() {
        //Get the last viewed position
        lastPosition = exoPlayer.getCurrentPosition();
        playBackStatus = exoPlayer.getPlayWhenReady();
    }

    private void releaseExoPlayer() {
        playerView.setPlayer(null);
        exoPlayer.release();
        exoPlayer = null;
    }


}
