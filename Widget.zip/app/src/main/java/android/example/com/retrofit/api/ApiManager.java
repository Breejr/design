package android.example.com.retrofit.api;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiManager {


    public static JsonRetrofitApi getClient() {

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://d17h27t6h515a5.cloudfront.net/") //Root URL
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        JsonRetrofitApi jsonRetrofitApi = retrofit.create(JsonRetrofitApi.class);

        return jsonRetrofitApi;

    }



}
