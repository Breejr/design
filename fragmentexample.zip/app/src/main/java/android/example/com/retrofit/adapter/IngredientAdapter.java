package android.example.com.retrofit.adapter;

import android.content.Context;
import android.example.com.retrofit.R;
import android.example.com.retrofit.model.Ingredients;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class IngredientAdapter extends RecyclerView.Adapter<IngredientAdapter.CustomViewHolder> {

        private Context mContext;
        private List<Ingredients> mIngredients;


        public IngredientAdapter(Context context, List<Ingredients> ingredients) {
            mContext = context;
            mIngredients = ingredients;
        }

        @NonNull
        @Override
        public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View v = LayoutInflater.from(mContext).inflate(R.layout.fragment_ingredient, parent, false);
            return new CustomViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {

            final Ingredients currentRecipe = mIngredients.get(position);

            final double quantity = currentRecipe.getQuantity();
            String measure = currentRecipe.getMeasure();
            String ingredient = currentRecipe.getIngredient();

            holder.quantity.setText(Double.toString(quantity));
            holder.measure.setText(measure);
            holder.ingredient.setText(ingredient);


            //holder.textViewID.setText(Integer.toString(recipeId));
           // holder.textViewName.setText(recipeLabel);


            //Click Listener for Recipe Cards

            holder.mCardView.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View view) {

                   // Intent mIntent = new Intent(mContext, IngredientActivity.class);
                    //mIntent.putExtra("recipeName", recipeLabel);
                    //mIntent.putExtra("recipeId", recipeId );

                    //mContext.startActivity(mIntent);
                }
            });

        }

        @Override
        public int getItemCount() {

            return mIngredients.size();
        }


        public class CustomViewHolder extends RecyclerView.ViewHolder {

            public TextView measure;
            public TextView quantity;
            public TextView ingredient;
            public CardView mCardView;


            public CustomViewHolder(View itemView) {
                super(itemView);
                //textViewID = itemView.findViewById(R.id.recipe_id);
                measure = itemView.findViewById(R.id.measure);
                quantity = itemView.findViewById(R.id.quantity);
                ingredient = itemView.findViewById(R.id.ingredient);
                mCardView = itemView.findViewById(R.id.card_view_ingredient);
            }

        }
    }


