package android.example.com.retrofit.fragments;

import android.content.Intent;
import android.example.com.retrofit.R;
import android.example.com.retrofit.activity.IngredientActivity;
import android.example.com.retrofit.adapter.IngredientAdapter;
import android.example.com.retrofit.api.ApiManager;
import android.example.com.retrofit.api.JsonRetrofitApi;
import android.example.com.retrofit.model.Ingredients;
import android.example.com.retrofit.model.Recipe;
import android.os.Bundle;


import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class IngredientFragment extends Fragment {

  private RecyclerView recyclerView;
  private int id;
  private IngredientAdapter ingredientAdapter;
  private List<Ingredients>ingredientList = null;
  private Recipe recipes;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_ingredient, container, false);

        getIngredients();

        return rootView;


    }

        public void getIngredients() {


        JsonRetrofitApi jsonRetrofitApi = ApiManager.getClient();

        Call<List<Recipe>> call = jsonRetrofitApi.getRecipes();

        call.enqueue(new Callback<List<Recipe>>() {
            @Override
            public void onResponse(Call<List<Recipe>> call, Response<List<Recipe>> response) {

                if (!response.isSuccessful()) {

                    return;
                }

                List<Recipe> jsonResponse = response.body();
                Log.e("TAG", String.valueOf(jsonResponse));
                generateList(jsonResponse);

            }

            @Override
            public void onFailure(Call<List<Recipe>> call, Throwable t) {


            }
        });
    }

    private void generateList(List<Recipe> jsonResponse) {

        Recipe recipe = null;

        for (Recipe r: jsonResponse) {
            if ((r.getId()==id)) {
                recipe = r;
                break;
            }
        }

        if (recipe == null) {
            return;
        } else {
            recyclerView = getActivity().findViewById(R.id.recycler_view_ingredient);
            recyclerView.setHasFixedSize(true);

            RecyclerView.LayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
            recyclerView.setLayoutManager(linearLayoutManager);


            ingredientAdapter = new IngredientAdapter(getContext(), recipe.getIngredients());
            recyclerView.setAdapter(ingredientAdapter);

        }

    }



}
