package android.example.com.retrofit.adapter;

import android.content.Context;
import android.content.Intent;
import android.example.com.retrofit.R;
import android.example.com.retrofit.activity.IngredientActivity;
import android.example.com.retrofit.model.Recipe;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MainAdapter extends RecyclerView.Adapter<MainAdapter.CustomViewHolder> {

    private Context mContext;
    private List<Recipe> mRecipes;


    public MainAdapter(Context context, List<Recipe> recipes) {
        mContext = context;
        mRecipes = recipes;
    }


    @NonNull
    @Override
    public MainAdapter.CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(mContext).inflate(R.layout.card_view_main, parent, false);
        return new CustomViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MainAdapter.CustomViewHolder holder, int position) {

        final Recipe currentRecipe = mRecipes.get(position);
        final String recipeLabel = currentRecipe.getName();
        final int recipeId = currentRecipe.getId();

        //holder.textViewID.setText(Integer.toString(recipeId));
        holder.textViewName.setText(recipeLabel);


        //Click Listener for Recipe Cards

        holder.mCardView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent mIntent = new Intent(mContext, IngredientActivity.class);
                mIntent.putExtra("recipeName", recipeLabel);
                mIntent.putExtra("recipeId", recipeId );

                mContext.startActivity(mIntent);
            }
        });

    }

    @Override
    public int getItemCount() {

        return mRecipes.size();
    }


    public class CustomViewHolder extends RecyclerView.ViewHolder {

        //public TextView textViewID;
        public TextView textViewName;
        //public TextView mId;
        public CardView mCardView;


        public CustomViewHolder(View itemView) {
            super(itemView);
            //textViewID = itemView.findViewById(R.id.recipe_id);
            textViewName = itemView.findViewById(R.id.recipe_name);
            mCardView = itemView.findViewById(R.id.card_view_main);
        }

    }
}
