package android.example.com.retrofit.model;

public class Ingredients {

    double quantity;
    String measure;
    String ingredient;
    private int id;

    public Ingredients(double quantity, String measure, String ingredient, int id) {
        this.quantity = quantity;
        this.measure = measure;
        this.ingredient = ingredient;
        this.id = id;

    }

    public double getQuantity() {
        return quantity;
    }

    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }

    public String getMeasure() {
        return measure;
    }

    public void setMeasure(String measure) {
        this.measure = measure;
    }

    public String getIngredient() {
        return ingredient;
    }

    public void setIngredient(String ingredient) {
        this.ingredient = ingredient;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
