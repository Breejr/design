package android.example.com.androidjokedisplay;

import android.content.Intent;
import android.example.com.javajokeslibrary.JavaJokes;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.util.ArrayList;

public class JokeMainLibrary extends AppCompatActivity {

    private ArrayList<String> mJokes;
    private String jokes;
    private TextView textView;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.joke_library_main);


/*
        jokes = "THIS IS A JOKE";
        JavaJokes javaJokes = new JavaJokes();
        jokes = javaJokes.getJokes();
       Log.e("ANDROID LIBRARY", jokes);
        textView = (TextView)findViewById(R.id.text_view_library);
        textView.setText("This is from library");
*/




        }

        public void libraryGetter() {
            jokes = "THIS IS A JOKE";

            JavaJokes javaJokes = new JavaJokes();
            jokes = javaJokes.getJokes();

            //Send Intent Broadcast
            Intent intent = new Intent("com.");
            intent.putExtra("jokesFromLibrary", jokes);
            Log.e("ANDROID LIBRARY", jokes);
            //I'm getting an error here I think because it's saying I'm sending a null object reference
            sendBroadcast(intent);



        }




}
