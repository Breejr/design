package com.udacity.gradle.builditbigger;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.example.com.androidjokedisplay.JokeMainLibrary;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.api.client.extensions.android.http.AndroidHttp;
import com.google.api.client.extensions.android.json.AndroidJsonFactory;
import com.google.api.client.googleapis.services.AbstractGoogleClientRequest;
import com.google.api.client.googleapis.services.GoogleClientRequestInitializer;
import com.udacity.gradle.builditbigger.backend.myApi.MyApi;
import com.udacity.gradle.builditbigger.backend.myApi.model.MyBean;

import java.io.IOException;

import javax.annotation.meta.When;


/**
 * A simple {@link Fragment} subclass.
 * Use the {@link LibraryFragmentMain#newInstance} factory method to
 * create an instance of this fragment.
 */
public class LibraryFragmentMain extends Fragment {

    private JokeMainLibrary jokeMainLibrary;
    public TextView textViewFragment;
    private BroadcastReceiver br;

    // TODO: Rename and change types of parameters
    private String jokes;
    public String response = "joke";
    public static String  received = "received";


    public LibraryFragmentMain() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment LibraryFragmentMain.
     */
    // TODO: Rename and change types and number of parameters
    public static LibraryFragmentMain newInstance(String param1, String param2) {
        LibraryFragmentMain fragment = new LibraryFragmentMain();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {


        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view =  inflater.inflate(R.layout.fragment_library_main, container, false);


       getIntent();


        return view;
    }

    public void getIntent() {

        //Create instance of Android Library
        jokeMainLibrary = new JokeMainLibrary();
        //Get Joke by sending Intent from the Library to here
        jokeMainLibrary.libraryGetter();

        createData();

    }


    public void createData() {

        new EndpointAsyncTask().execute(this);
        //textViewFragment = getActivity().findViewById(R.id.library_frag_txt);
       // Log.e("CREATE DATA", received);
        //textViewFragment.setText(received);
    }

}

class MyBroadcastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        LibraryFragmentMain libraryFragmentMain = new LibraryFragmentMain();
        LibraryFragmentMain.received = intent.getExtras().getString("jokesFromLibrary");
        libraryFragmentMain.createData();

    }
}


//Async Task
 class EndpointAsyncTask extends AsyncTask<LibraryFragmentMain, Void, String> {
    private  MyApi myApiService = null;
    private Context context;
    private LibraryFragmentMain libraryFragmentMain;

    @Override
    protected String doInBackground(LibraryFragmentMain... params) {
        if(myApiService == null) {  // Only do this once
            MyApi.Builder builder = new MyApi.Builder(AndroidHttp.newCompatibleTransport(),
                    new AndroidJsonFactory(), null)
                    // options for running against local devappserver
                    // - 10.0.2.2 is localhost's IP address in Android emulator
                    // - turn off compression when running against local devappserver
                    .setRootUrl("http://10.0.2.2:8080/_ah/api/")
                    .setGoogleClientRequestInitializer(new GoogleClientRequestInitializer() {
                        @Override
                        public void initialize(AbstractGoogleClientRequest<?> abstractGoogleClientRequest) throws IOException {
                            abstractGoogleClientRequest.setDisableGZipContent(true);
                        }
                    });
            // end options for devappserver

            myApiService = builder.build();
        }

        //context = params[0].first;
        context = libraryFragmentMain.getActivity();
        libraryFragmentMain = params[0];
        //String joke = params[0].second;

        try {
            return myApiService.grabJokes().execute().getData();
        } catch (IOException e) {
            return e.getMessage();
        }
    }

    @Override
    protected void onPostExecute(String result) {

        libraryFragmentMain.response = result;
        libraryFragmentMain.getIntent();
        //Toast.makeText(context, result, Toast.LENGTH_LONG).show();


    }


}

