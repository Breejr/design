package android.example.com.androidjokedisplay;

import android.example.com.javajokeslibrary.JavaJokes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.util.ArrayList;

public class JokeMainLibrary extends AppCompatActivity {

    private ArrayList<String> mJokes;
    private JavaJokes javaJokes;
    private String jokes;
    private TextView textView;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        javaJokes = new JavaJokes();
        jokes = JavaJokes.getJokes();

        Log.e("LIBRARY", jokes);

        textView.findViewById(R.id.libary_joke);

        textView.setText(jokes);

        //Send Joke to Intent
/*        Intent intent = new Intent(this, JokeMainLibrary.class);
        intent.putExtra("jokes", jokes);
        startActivity(intent);*/



        }




}
