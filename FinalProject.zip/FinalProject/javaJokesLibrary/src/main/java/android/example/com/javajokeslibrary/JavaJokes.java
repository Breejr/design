package android.example.com.javajokeslibrary;

import com.sun.corba.se.spi.activation.BadServerDefinition;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import sun.rmi.runtime.Log;


public class JavaJokes {

    //http://www.devtopics.com/best-programming-jokes/

    private static final ArrayList<String> jokes = new ArrayList<String>() {
        {

            jokes.add("TEST");
            jokes.add("TEST2");

        }
    };

    public static String getJokes() {

        String firstJoke = jokes.get(0);
        return firstJoke;


    }



}
