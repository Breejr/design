package android.example.com.retrofit.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.example.com.retrofit.R;
import android.os.Bundle;

public class StepsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_steps);
    }
}
