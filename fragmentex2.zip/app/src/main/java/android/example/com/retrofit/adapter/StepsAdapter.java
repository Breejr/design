package android.example.com.retrofit.adapter;

import android.content.Context;
import android.example.com.retrofit.R;
import android.example.com.retrofit.model.Ingredients;
import android.example.com.retrofit.model.Steps;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class StepsAdapter extends RecyclerView.Adapter<StepsAdapter.CustomViewHolder> {

    private Context mContext;
    private List<Steps> mSteps;


    public StepsAdapter(Context context, List<Steps> steps) {
        mContext = context;
        mSteps = steps;
    }

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(mContext).inflate(R.layout.fragment_steps, parent, false);
        return new CustomViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {

        final Steps currentRecipe = mSteps.get(position);

        final int stepID = currentRecipe.getId();
        String shortDescription = currentRecipe.getShortDescription();
        String videoUrl = currentRecipe.getVideoURL();
        String thumbnailUrl = currentRecipe.getThumbnailURL();

        holder.stepIdTV.setText(Integer.toString(stepID));
        holder.shortDescriptionTV.setText(shortDescription);
        holder.videoUrlTV.setText(videoUrl);
        holder.thumbnailUrlTV.setText(thumbnailUrl);


        //holder.textViewID.setText(Integer.toString(recipeId));
        // holder.textViewName.setText(recipeLabel);


        //Click Listener for Recipe Cards

        holder.mCardView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                // Intent mIntent = new Intent(mContext, IngredientActivity.class);
                //mIntent.putExtra("recipeName", recipeLabel);
                //mIntent.putExtra("recipeId", recipeId );

                //mContext.startActivity(mIntent);
            }
        });

    }

    @Override
    public int getItemCount() {

        return mSteps.size();
    }


    public class CustomViewHolder extends RecyclerView.ViewHolder {

        public TextView stepIdTV;
        public TextView shortDescriptionTV;
        public TextView videoUrlTV;
        public TextView thumbnailUrlTV;
        public CardView mCardView;


        public CustomViewHolder(View itemView) {
            super(itemView);

            stepIdTV = itemView.findViewById(R.id.id_fragment);
            shortDescriptionTV = itemView.findViewById(R.id.shortdescription_fragment);
            videoUrlTV = itemView.findViewById(R.id.video_fragment);
            thumbnailUrlTV = itemView.findViewById(R.id.thumbnail_fragment);
            mCardView = itemView.findViewById(R.id.card_view_steps_fragment);
        }

    }
}