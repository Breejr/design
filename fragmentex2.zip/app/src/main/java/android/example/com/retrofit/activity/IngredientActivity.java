package android.example.com.retrofit.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.example.com.retrofit.adapter.IngredientAdapter;
import android.example.com.retrofit.R;
import android.example.com.retrofit.api.ApiManager;
import android.example.com.retrofit.api.JsonRetrofitApi;
import android.example.com.retrofit.fragments.IngredientFragment;
import android.example.com.retrofit.model.Ingredients;
import android.example.com.retrofit.model.Recipe;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class IngredientActivity extends AppCompatActivity {

    private int id;
    private ArrayList<Ingredients> ingredientsArrayList;
    private Ingredients ingredients;
    private RecyclerView recyclerView;
    private IngredientAdapter ingredientAdapter;
    private FragmentManager fragmentManager;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingredient);



        Intent intent = getIntent();

        id = intent.getIntExtra("recipeId", 0);

        //getIngredients();

        //Instantiate New Fragment
        IngredientFragment fragment = new IngredientFragment();

        //Pass ID to the fragment through arguments
        Bundle args = new Bundle();
        args.putInt("recipeId", id);
        fragment.setArguments(args);

        //Fragment Transaction
        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .add(R.id.ingredient_content, fragment)
                .commit();

    }


/*    public void getIngredients() {

        ingredientsArrayList = new ArrayList<>();

        JsonRetrofitApi jsonRetrofitApi = ApiManager.getClient();

        Call<List<Recipe>> call = jsonRetrofitApi.getRecipes();

        call.enqueue(new Callback<List<Recipe>>() {
            @Override
            public void onResponse(Call<List<Recipe>> call, Response<List<Recipe>> response) {

                if (!response.isSuccessful()) {

                    return;
                }

                List<Recipe> jsonResponse = response.body();
                Log.e("TAG", String.valueOf(jsonResponse));
                generateList(jsonResponse);

            }

            @Override
            public void onFailure(Call<List<Recipe>> call, Throwable t) {


            }
        });
    }

    private void generateList(List<Recipe> jsonResponse) {

        Recipe recipe = null;

        for (Recipe r: jsonResponse) {
            if ((r.getId()==id)) {
                recipe = r;
                break;
            }
        }

        if (recipe == null) {
            return;
        } else {
            recyclerView = findViewById(R.id.recycler_view_ingredient);
            recyclerView.setHasFixedSize(true);

            RecyclerView.LayoutManager linearLayoutManager = new LinearLayoutManager(IngredientActivity.this);
            recyclerView.setLayoutManager(linearLayoutManager);


            ingredientAdapter = new IngredientAdapter(this, recipe.getIngredients());
            recyclerView.setAdapter(ingredientAdapter);

        }

    }*/



}
