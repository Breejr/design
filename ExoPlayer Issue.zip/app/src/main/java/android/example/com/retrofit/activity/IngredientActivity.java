package android.example.com.retrofit.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.TextViewCompat;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager.widget.PagerTabStrip;
import androidx.viewpager.widget.ViewPager;
import android.content.Intent;
import android.content.res.Configuration;
import android.example.com.retrofit.BuildConfig;
import android.example.com.retrofit.ReleaseTree;
import android.example.com.retrofit.adapter.FragmentPagerAdapter;
import android.example.com.retrofit.R;
import android.example.com.retrofit.fragments.IngredientFragment;
import android.example.com.retrofit.fragments.StepDetailsFragment;
import android.example.com.retrofit.fragments.StepsFragment;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;


import timber.log.Timber;

public class IngredientActivity extends AppCompatActivity {

    private int id;
    private FragmentManager fragmentManager;
    FragmentPagerAdapter adapterViewPager;
    private TextView firstTextView;
    private TextView secondTextView;
    private TextView thirdTextView;
    private PagerTabStrip pagerTabStrip;
    private boolean twoPane;
    private int orientation;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingredient);

        //Grab recipe ID from intent
        Intent intent = getIntent();

        id = intent.getIntExtra("recipeId", 0);

        //Plant Timber for Debug
        if (BuildConfig.DEBUG) {
            Timber.plant(new Timber.DebugTree());
        } else {
            Timber.plant(new ReleaseTree());
        }

        //Set to Tablet
        if(getResources().getBoolean(R.bool.isTab)) {
            Timber.e("TABLET");
            twoPane = true;
            Timber.e(String.valueOf(twoPane));

        //Set to Mobile
        } else {
            Timber.e("PHONE");
            Timber.e(String.valueOf(twoPane));
            twoPane = false;
        }


        //Find the views for the title bar
        firstTextView = findViewById(R.id.firstTextView);
        secondTextView = findViewById(R.id.secondTextView);
        thirdTextView = findViewById(R.id.thirdTextView);

        //Set Text appearance for header
        TextViewCompat.setTextAppearance(firstTextView,R.style.RecyclerViewOutput);
        TextViewCompat.setTextAppearance(secondTextView,R.style.RecyclerViewOutput);
        TextViewCompat.setTextAppearance(thirdTextView,R.style.RecyclerViewOutput);

        //Find ViewPager and adapter
        final ViewPager viewPager = findViewById(R.id.viewPager);
        adapterViewPager = new FragmentPagerAdapter(getSupportFragmentManager());
        viewPager.setAdapter(adapterViewPager);

        //Default view Ingredient Fragment
        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.fragment_content, IngredientFragment.newInstance(1, "Ingredients", id))
                .commit();


        //Stylize ViewPager Strip
        pagerTabStrip = findViewById(R.id.pager_header);
        pagerTabStrip.setTabIndicatorColor(Color.WHITE);
        pagerTabStrip.setTextColor(Color.WHITE);


        // Attach the page change listener inside the activity
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {

            // This method will be invoked when a new page becomes selected.
            @Override
            public void onPageSelected(int position) {
                Toast.makeText(IngredientActivity.this,
                        "Selected page position: " + position, Toast.LENGTH_SHORT).show();

                adapterViewPager.notifyChangeInPosition(1);
                adapterViewPager.notifyDataSetChanged();

                //IF ViewPager slider is on Ingredients, show the following fragment:
                if (position == 0) {

                    firstTextView.setText("Size:");
                    secondTextView.setText("Measure");
                    thirdTextView.setText("Ingredient");


                    if (twoPane) {
                        //Fragment Transaction
                        fragmentManager = getSupportFragmentManager();
                        fragmentManager.beginTransaction()
                                .replace(R.id.fragment_content, IngredientFragment.newInstance(1, "Test", id))
                                .remove(getSupportFragmentManager().findFragmentById(R.id.exoplayer_content))
                                .commit();

                    }

                    if (!twoPane) {

                        //Fragment Transaction
                        fragmentManager = getSupportFragmentManager();
                        fragmentManager.beginTransaction()
                                .replace(R.id.fragment_content, IngredientFragment.newInstance(1, "Test", id))
                                .commit();

                        adapterViewPager.notifyDataSetChanged();

                    }

                    //If ViewPager slider is on Steps, show the following fragment
                } else if (position == 1) {

                    //If twopane=false, show the following fragment from StepsFragment
                    if (!twoPane) {
                        firstTextView.setText("Title");
                        secondTextView.setText("Description");
                        thirdTextView.setText("Video");


                        //Fragment Transaction
                        fragmentManager = getSupportFragmentManager();
                        fragmentManager.beginTransaction()
                                .replace(R.id.fragment_content, StepsFragment.newInstance(1, "Test", id))
                                .commit();

                        adapterViewPager.notifyDataSetChanged();

                    }

                    //If twopane = true, and orientation is landscape
                    else if (twoPane && orientation==1) {

                        firstTextView.setText("Title");
                        secondTextView.setText("Description");
                        thirdTextView.setText("Video");

                        //Fragment Transaction
                        fragmentManager = getSupportFragmentManager();
                        fragmentManager.beginTransaction()
                                .replace(R.id.fragment_content, StepsFragment.newInstance(1, "Test", id))
                                .commit();

                        adapterViewPager.notifyDataSetChanged();


                        //Fragment Transaction
                        fragmentManager = getSupportFragmentManager();
                        fragmentManager.beginTransaction()
                                .replace(R.id.exoplayer_content, StepDetailsFragment.newInstance(1, "Test", id, ""))
                                .commit();

                        adapterViewPager.notifyDataSetChanged();

                    }
                    //Anything else show original single layout fragment
                    else {

                        firstTextView.setText("Title");
                        secondTextView.setText("Description");
                        thirdTextView.setText("Video");


                        //Fragment Transaction
                        fragmentManager = getSupportFragmentManager();
                        fragmentManager.beginTransaction()
                                .replace(R.id.fragment_content, StepsFragment.newInstance(1, "Test", id))
                                .commit();

                        adapterViewPager.notifyDataSetChanged();

                    }

                }

            }

            // This method will be invoked when the current page is scrolled
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                // Code goes here
            }

            // Called when the scroll state changes:
            // SCROLL_STATE_IDLE, SCROLL_STATE_DRAGGING, SCROLL_STATE_SETTLING
            @Override
            public void onPageScrollStateChanged(int state) {
                // Code goes here
            }
        });

    }

    @Override
    public void onResume() {

        //Get Screen Orientation

        orientation = getResources().getConfiguration().orientation;

        if(orientation == Configuration.ORIENTATION_LANDSCAPE) {
            //Screen is in landscape mode
            Timber.e("LANDSCAPE MODE");
            orientation = 1;

        } else {

            //Screen is in portrait mode
            orientation = 0;
            Timber.e("PORTRAIT MODE");
        }
        super.onResume();
    }


}
