package android.example.com.retrofit.model;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class Recipe {

private int id;
private String name;
private ArrayList<Recipe> jsonRecipes;
private List<Ingredients> ingredients = null;
private List<Steps> steps = null;


public Recipe(int id, String name) {
    this.id = id;
    this.name = name;
}

    public void setJsonRecipes(ArrayList<Recipe> jsonRecipes) {
        this.jsonRecipes = jsonRecipes;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Ingredients> getIngredients() {
        return ingredients;
    }

    public void setIngredients(List<Ingredients> ingredients) {
        this.ingredients = ingredients;
    }

    public List<Steps> getSteps() {
        return steps;
    }

    public void setSteps(List<Steps> steps) {
        this.steps = steps;
    }
}
