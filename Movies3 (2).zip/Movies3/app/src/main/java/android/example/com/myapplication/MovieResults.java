package android.example.com.myapplication;

import android.graphics.Movie;

import java.util.ArrayList;

public class MovieResults {

    private String author;
    private String review;

    public MovieResults(String author, String review) {

        this.author = author;
        this.review = review;

    }


    public String getAuthor() {
        return author;
    }

    public String getReview() {
        return review;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setReview(String review) {
        this.review = review;
    }
}
