package android.example.com.myapplication.Reviews;

import android.content.Intent;
import android.example.com.myapplication.MovieResults;
import android.example.com.myapplication.R;
import android.os.Bundle;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ReviewDetails extends AppCompatActivity  {

    public int mId;
    private String url;
    private RequestQueue mRequestQueue;
    private String author;
    private String review;
    private RecyclerView mRecyclerView;
    private ReviewAdapter mReviewAdapter;
    private MovieResults movieResults;
    private ArrayList<MovieResults> reviewsArray;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_review_details);

        mRecyclerView = findViewById(R.id.recycler_view_review);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));


        reviewsArray = new ArrayList<>();


        mRequestQueue = Volley.newRequestQueue(this);

        //Get API for reviews
        Intent intent = getIntent();
        url = intent.getStringExtra("url");

        parseReviews();

    }

    public void parseReviews() {

        Log.e("URL", url);

        movieResults = new MovieResults("author", "review");


        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        try {

                            JSONArray jsonArray = response.getJSONArray("results");

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject results = jsonArray.getJSONObject(i);

                                Log.e("JSONARRAY SIZE", Integer.toString(jsonArray.length()));

                                author = results.getString("author");

                                movieResults.setAuthor(author);

                                review = results.getString("content");
                                movieResults.setReview(review);
                                reviewsArray.add(new MovieResults(author, review));

                                printReviews();
                            }

                            mRecyclerView.setAdapter(mReviewAdapter);
                            mReviewAdapter = new ReviewAdapter(ReviewDetails.this, reviewsArray);
                        }

                        catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        mRequestQueue.add(request);
    }

    public void printReviews() {

        //Find the linear layout in content_review_details.xml
        LinearLayout layout = findViewById(R.id.linear_nested);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        //Programmatically create Author Text View
        TextView authorTxt = new TextView(new ContextThemeWrapper(this, R.style.header_reviews), null, 0);
        authorTxt.setText(getResources().getString(R.string.author) + " " + author);
        layout.addView(authorTxt);

        //Programmatically create Reviews Text View
        TextView reviewTxt = new TextView(new ContextThemeWrapper(this, R.style.blockText), null, 0);
        reviewTxt.setText(review);
        layout.addView(reviewTxt);

    }



 }

