package android.example.com.myapplication.database;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.Index;
import androidx.room.PrimaryKey;

import java.util.ArrayList;

@Entity(tableName = "favorites", indices = {@Index(value = {"movieId"}, unique = true)})
public class Movies {

    @PrimaryKey(autoGenerate = true)
    private int id;
    @ColumnInfo(name = "movieId")
    public int mId;


    public int getmId() {
        return this.mId;
    }

    public void setmId (int mId) {
        this.mId = mId;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }


    @Ignore
    private String poster_path;
    @Ignore
    private String releaseDate;
    @Ignore
    private String original_title;
    @Ignore
    private String overview;
    @Ignore
    private double vote_average;

    public Movies(int id, int mId) {

        this.mId = mId;
        this.id = id;
    }


@Ignore
   public Movies(String imageUrl, int id, String original_title, String overview, double vote_average, String releaseDate) {
        poster_path = imageUrl;
        mId = id;
        this.original_title = original_title;
        this.overview = overview;
        this.vote_average = vote_average;
        this.overview = overview;
        this.releaseDate = releaseDate;
    }

@Ignore
    public Movies (String imageUrl) {
        poster_path = imageUrl;
    }



    public String getOverview() {
        return overview;
    }

    public double getVoterAverage() {
        return vote_average;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }


    public void setOverview(String overview) {
        this.overview = overview;
    }

    public void setVoterAverage(double vote_average) {
        this.vote_average = vote_average;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public String getOriginalTitle() {
        return original_title;
    }

    public void setOriginalTitle(String original_title) {
        this.original_title = original_title;
    }

    public String getPoster_path() {
        return poster_path;

    }

    public void setmImageUrl(String poster_path) {
        this.poster_path = poster_path;
    }


}


