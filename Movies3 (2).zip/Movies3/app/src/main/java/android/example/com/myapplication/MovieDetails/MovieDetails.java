package android.example.com.myapplication.MovieDetails;

import android.content.Context;
import android.content.Intent;
import android.example.com.myapplication.AppExecutors;
import android.example.com.myapplication.R;
import android.example.com.myapplication.Reviews.ReviewDetails;
import android.example.com.myapplication.database.FavoriteDatabase;
import android.example.com.myapplication.database.Movies;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.youtube.player.YouTubeBaseActivity;
import com.squareup.picasso.Picasso;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;


public class MovieDetails extends YouTubeBaseActivity implements View.OnClickListener {

    final String BASE_URL = "https://api.themoviedb.org/3/";
    final String MOVIE_ADD = "movie/";
    final String REVIEW_ADD = "/reviews";
    final String TRAILER_URL = "https://www.youtube.com/watch?v=";
    private RequestQueue mRequestQueue;
    final String API_KEY = "YOUR API KEY";
    public int mId;
    private int id;
    private ArrayList<String> keys = new ArrayList<>();
    private ArrayList<String> trailerNames = new ArrayList<>();
    private int totalTrailers;
    private int rowNumber = 0;
    private int indexOfArray;
    private String saved_key;
    private Movies movies;
    private FavoriteDatabase favoriteDatabase;
    private String title;
    private List<Movies> favorites = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.movie_details);


        Intent intent = getIntent();

        //Grab Intents Stored
        title = intent.getStringExtra("currentTitle");
        double rating = intent.getDoubleExtra("currentAverage", 0.0);
        String date = intent.getStringExtra("currentDate");
        String overview = intent.getStringExtra("currentOverview");
        String image = intent.getStringExtra("imageUrl");
        mId = intent.getIntExtra("currentId", 0);



        //Set TextViews
        TextView tvTitle = findViewById(R.id.movie_title);
        TextView tvRating = findViewById(R.id.rating);
        TextView tvDate = findViewById(R.id.released_date);
        TextView tvOverview = findViewById(R.id.overview_text);
        ImageView ivImageView = findViewById(R.id.image_view_details);


        //Set Intents to TextViews
        tvTitle.setText(title);
        tvRating.setText(String.valueOf(rating));
        tvDate.setText(date);
        tvOverview.setText(overview);

        //Load Image
        Picasso.get()
                .load(image)
                .into(ivImageView);

        mRequestQueue = Volley.newRequestQueue(this);

        parseVideo();

        favoriteDatabase = FavoriteDatabase.getInstance(getApplicationContext());


        //Create click listeners for favorite and reviews button
        final Button buttonFavorite = findViewById(R.id.button_favorite);
        buttonFavorite.setOnClickListener(this);

        final Button buttonReviews = findViewById(R.id.button_reviews);
        buttonReviews.setOnClickListener(this);

        checkList();

    }

    //Get video paths for movie ID
    private void parseVideo() {

        //Log.e("ID!!!!", Integer.toString(id));
        //Log.e("VIDEO PATH!!!", VIDEO_PATH);

        String VIDEO_PATH = BASE_URL + "movie/" + mId + "/" + "videos" + API_KEY;

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, VIDEO_PATH, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        try {
                            JSONArray jsonArray = response.getJSONArray("results");


                            for (int i = 0; i < jsonArray.length(); i++) {

                                JSONObject results = jsonArray.getJSONObject(i);

                                final String my_key = results.getString("key");
                                final String name = results.getString("name");
                                //Add Key To ArrayList
                                keys.add(TRAILER_URL + my_key);
                                //Add Trailer Name to ArrayList
                                trailerNames.add(name);


                                saved_key = my_key;
                                addView();

                            }

                            //DEBUGGING
/*                          Log.e("KEYS", Integer.toString(keys.size()));
                            Log.e("KEYS", Integer.toString(rowNumber));*/

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });


        mRequestQueue.add(request);
    }

//Create table rows
    public void addView() {

        //DEBUGGING
        // Log.e("addview", saved_key);
        //totalTrailers += 1;


        TableLayout tableLayout = findViewById(R.id.table_layout);
        final TableRow tableRow = new TableRow(new ContextThemeWrapper(this, R.style.tableRows), null);

        // allows you to click a specific row
        tableRow.setClickable(true);

        //Set Id of row
        tableRow.setId(rowNumber);
        tableLayout.addView(tableRow);
        //Create a click listener for each table row created
        tableRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Get ID of ROW Clicked
                indexOfArray = tableRow.getId();
                //Store url into the index of the array clicked
                String url = "";
                url = keys.get(indexOfArray);

                //DEBUGGING
/*              Log.e("ROW CLICKED", Integer.toString(indexOfArray));
                Log.e("ARRAY", keys.get(indexOfArray));
                Log.e("ARRAY SIZE", Integer.toString(keys.size()));*/

                //Open Intent to Browser or Youtube App
              Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);

            }
        });

        //Create Image View
        ImageView imageView = new ImageView(this);
        tableRow.addView(imageView);
        imageView.setImageResource(R.drawable.ic_play_button);


        //Create Trailer
        TextView textView = new TextView(this);
        tableRow.addView(textView);

        textView.setText(trailerNames.get(rowNumber));
        textView.setTextSize(TypedValue.COMPLEX_UNIT_PX, getResources().getDimensionPixelSize(R.dimen.standard_txt_size));
        //Increment Row Number
        rowNumber += 1;


    }


    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            //Favorites clicked, movie ID will be added to intent

            case R.id.button_favorite:
                movies = new Movies(id, mId);

                AppExecutors.getInstance().diskIO().execute(new Runnable() {
                    @Override
                    public void run() {

                        favoriteDatabase.myDao().addFavorites(movies);

                    }}); // End AppExecutors
                movies.setmId(mId);

                //Toast message for which movie was added to favorites
                Toast.makeText(getApplicationContext(),getResources().getString(R.string.Added) + " " +  title, Toast.LENGTH_SHORT).show();
                break;

                //If button reviews are clicked, the URL will be saved for the review API based on movie ID
            case R.id.button_reviews:

                String url = BASE_URL + MOVIE_ADD + mId + REVIEW_ADD + API_KEY;
                Intent intent = new Intent(this, ReviewDetails.class);
                intent.putExtra("url", url);
                startActivity(intent);

        }

    }

    public void checkList() {

        final Button favButton = findViewById(R.id.button_favorite);

        AppExecutors.getInstance().diskIO().execute(new Runnable() {
            @Override
            public void run() {
                favorites = favoriteDatabase.myDao().getFavorites();

                for (int i = 0; i<favorites.size(); i++) {


                    int checkID = favorites.get(i).getmId();
                    Log.e("CHECK", Integer.toString(checkID));

                    if (checkID == mId) {

//Created UI update on the main thread https://stackoverflow.com/questions/5161951/android-only-the-original-thread-that-created-a-view-hierarchy-can-touch-its-vi
                        try {
                            synchronized (this) {
                                wait(5000);
                            }
                            runOnUiThread(new Runnable() {
                                @Override
                                //Updates Favorite button to "My Favorite!" if it's already located in the database
                                public void run() {
                                    favButton.setText(getResources().getString(R.string.favorite));

                                }
                            });
                        }
                        catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                    }
                }

            }
        });
    }


}








