package android.example.com.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.example.com.myapplication.database.FavoriteDatabase;
import android.example.com.myapplication.database.Movies;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private RecyclerView mRecyclerView;
    private CustomAdapter mCustomAdapter;
    private ArrayList<Movies> mMovies;
    private RequestQueue mRequestQueue;
    public Movies movies;
    final String IMAGE_BASE_URL = "https://image.tmdb.org/t/p/w500";
    final String BASE_URL = "https://api.themoviedb.org/3/";
    final String POPULAR_MOVIES = "movie/popular";
    final String TOP_RATED = "movie/top_rated";
    final String FAVORITE_ID = "movie/";
    final String API_KEY = "?api_key=2ddc5c2256005b5ae43fec5137947064";
    public FavoriteDatabase favoriteDatabase;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        mRecyclerView = findViewById(R.id.recycler_view);
        Spinner spinner = findViewById(R.id.spinner);
        mRecyclerView.setHasFixedSize(true);


        //Set two columns in a grid layout https://www.codingdemos.com/android-cardview-example-with-gridlayout/

        GridLayoutManager mGridLayoutManager = new GridLayoutManager(MainActivity.this, 2);

        //Set recycler view to layout manager
        mRecyclerView.setLayoutManager(mGridLayoutManager);

        //Spinner Coding in Flow https://www.youtube.com/watch?v=on_OrrX7Nw4
        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(this, R.array.spinner, android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(spinnerAdapter);
        spinner.setOnItemSelectedListener(this);


        //Initalize movie detail arraylist
        mMovies = new ArrayList<>();

        //Initialize Volley
        mRequestQueue = Volley.newRequestQueue(this);

        //Initialize database
        favoriteDatabase = FavoriteDatabase.getInstance(getApplicationContext());


    }


    private void parseJSONPopular() {

        String url = BASE_URL + POPULAR_MOVIES + API_KEY;

        movies = new Movies("test", 123, "title", "overview", 7.2, "date");


        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {


                        try {
                            JSONArray jsonArray = response.getJSONArray("results");

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject results = jsonArray.getJSONObject(i);

                                movies.setmImageUrl(IMAGE_BASE_URL + results.getString("poster_path"));

                                String imageUrl = movies.getPoster_path();

                                //Grab Movie ID
                                int id = results.getInt("id");
                                movies.setmId(id);

                                //Grab Movie Title
                                String title = results.getString("original_title");
                                movies.setOriginalTitle(title);

                                //Grab movie Overview
                                String overview = results.getString("overview");
                                movies.setOverview(overview);

                                //Grab movie average
                                double average = results.getDouble("vote_average");
                                movies.setVoterAverage(average);

                                //Grab Release Date
                                String date = results.getString("release_date");
                                movies.setReleaseDate(date);

                                mMovies.add(new Movies(imageUrl, id, title, overview, average, date));

                                //Log.e("Main Activity!!!!", Integer.toString(id));

                            }

                            mCustomAdapter = new CustomAdapter(MainActivity.this, mMovies);
                            mRecyclerView.setAdapter(mCustomAdapter);
                        }

                        catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        mRequestQueue.add(request);
    }


    private void parseJSONTopRated () {
        String url = BASE_URL + TOP_RATED + API_KEY;
        movies = new Movies("test", 123, "title", "overview", 7.2, "date");

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {


                        try {
                            JSONArray jsonArray = response.getJSONArray("results");

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject results = jsonArray.getJSONObject(i);

                                movies.setmImageUrl(IMAGE_BASE_URL + results.getString("poster_path"));

                                String imageUrl = movies.getPoster_path();

                                //Grab Movie ID
                                int id = results.getInt("id");
                                movies.setmId(id);

                                //Grab Movie Title
                                String title = results.getString("original_title");
                                movies.setOriginalTitle(title);

                                //Grab movie Overview
                                String overview = results.getString("overview");
                                movies.setOverview(overview);

                                //Grab movie average
                                double average = results.getDouble("vote_average");
                                movies.setVoterAverage(average);

                                //Grab Release Date
                                String date = results.getString("release_date");
                                movies.setReleaseDate(date);

                                mMovies.add(new Movies(imageUrl, id, title, overview, average, date));

                            }

                            mCustomAdapter = new CustomAdapter(MainActivity.this, mMovies);
                            mRecyclerView.setAdapter(mCustomAdapter);
                        }

                        catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        mRequestQueue.add(request);
    }

    private void parseFavorites() {

        movies = new Movies("test", 123, "title", "overview", 7.2, "date");


        // NEW LIVE DATA LIST
        final LiveData<List<Movies>> allFavorites = favoriteDatabase.myDao().getAllFavorites();

        // IF I DO THIS IT WORKS GREAT BUT IT'S NOT USING LIVE DATA? where am I supposed to use this...
        //List<Movies> allFavorites = favoriteDatabase.myDao().getFavorites();

        favoriteDatabase.myDao().getFavorites();

        //CREATE LIVE DATA, when there is a change, grab all of the JSON data. I guess? Maybe I should be doing something else...

        favoriteDatabase.myDao().getAllFavorites().observe(this, new Observer<List<Movies>>() {
            @Override
            public void onChanged(List<Movies> movies) {




        // OLD WAY BELOW:

        /*//Create SQL query async task
        AppExecutors.getInstance().diskIO().execute(new Runnable() {
            @Override
            public void run() {

                List<Movies> allFavorites = favoriteDatabase.myDao().getFavorites();
                favoriteDatabase.myDao().getFavorites();*/

        // LOOP through all the favorites in the database, for each one get their ID, and grab the corresponding JSON

                for (int i = 0; i < allFavorites.size(); i++) {

                    int favoriteId = allFavorites.get(i).getmId();


                    //DEBUGGING OLD WAY
/*          final int arraySize = allFavorites.size();
            System.out.println(allFavorites.get(i).getmId());
            Log.e("Array Size", Integer.toString(arraySize)); */

                    String url = BASE_URL + FAVORITE_ID + favoriteId + API_KEY;
                    //Log.e("FAVORITE URL", url);


                    JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                            new Response.Listener<JSONObject>() {
                                @Override
                                public void onResponse(JSONObject response) {

                                    try {

                                        String jsonObject = response.getString("poster_path");


                                        // I CAN'T ACCESS MOVIES NOW THAT I ADDED, EVEN THOUGH I MADE THE VARIABLE PUBLIC?

                                        //Grab and set imageURL for poster path
                                        movies.setmImageUrl(IMAGE_BASE_URL + jsonObject);
                                        String imageUrl = movies.getPoster_path();

                                        //Grab Movie ID
                                        int mId = response.getInt("id");
                                        movies.setmId(mId);

                                        //Grab Movie Title
                                        String title = response.getString("original_title");
                                        movies.setOriginalTitle(title);

                                        //Grab movie Overview
                                        String overview = response.getString("overview");
                                        movies.setOverview(overview);

                                        //Grab movie average
                                        double average = response.getDouble("vote_average");
                                        movies.setVoterAverage(average);

                                        //Grab Release Date
                                        String date = response.getString("release_date");
                                        movies.setReleaseDate(date);

                                        //mMovies.add(new Movies(imageUrl, mId, title, overview, average, date));


                                        mCustomAdapter = new CustomAdapter(MainActivity.this, mMovies);
                                        mRecyclerView.setAdapter(mCustomAdapter);
                                    }

                                    catch (JSONException e) {
                                        e.printStackTrace();
                                    }

                                }
                            }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            error.printStackTrace();
                        }
                    });

                    mRequestQueue.add(request);

                }

            }
        }); // END OF LIVE DATA


           /* }})*/; // End AppExecutors

}


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        long selection = parent.getItemIdAtPosition(position);

        if (selection == 0) {
            //Clear Array for change in selection
            mMovies.clear();
            //Create Top Rated Movie List
            parseJSONPopular();

        }
        else if (selection == 1) {
            //Clear Array for change in selection
            mMovies.clear();
            //Create Top Rated Movie List
            parseJSONTopRated();
        }

        else if (selection == 2) {
            //Clear Array for change in selection
            mMovies.clear();
            //Create Favorites Movie List
            parseFavorites();
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

}
