package android.example.com.myapplication;

import android.content.Context;
import android.content.Intent;
import android.example.com.myapplication.MovieDetails.MovieDetails;
import android.example.com.myapplication.database.Movies;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.CustomViewHolder> {

    private Context mContext;
    private ArrayList<Movies> mMovies;


    public CustomAdapter(Context context, ArrayList<Movies> movies) {
        mContext = context;
        mMovies = movies;
    }



    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.card_item, parent, false);
        return new CustomViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final CustomViewHolder holder, final int position) {

        final Movies currentItem = mMovies.get(position);
        final String imageUrl = currentItem.getPoster_path();

        //Picasso adds images to imageView

        Picasso.get()
                .load(imageUrl)
                .into(holder.mImageView);


        //Click Listener for the movie posters
        holder.mCardView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick (View view) {

                final String currentTitle = currentItem.getOriginalTitle();
                final double currentAverage = currentItem.getVoterAverage();
                final String currentDate = currentItem.getReleaseDate();
                final String currentOverview = currentItem.getOverview();
                final int currentId = currentItem.getmId();


                Intent mIntent = new Intent(mContext, MovieDetails.class);
                mIntent.putExtra("currentTitle",currentTitle );
                mIntent.putExtra("imageUrl",imageUrl );
                mIntent.putExtra("currentAverage", currentAverage);
                mIntent.putExtra("currentDate", currentDate);
                mIntent.putExtra("currentOverview", currentOverview);
                mIntent.putExtra("currentId", currentId);
                mContext.startActivity(mIntent);

            }
        });

    }

    @Override
    public int getItemCount() {
        return mMovies.size();
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder {

        public ImageView mImageView;
        //public TextView mId;
        public CardView mCardView;


        public CustomViewHolder(View itemView) {
            super(itemView);
            mImageView = itemView.findViewById(R.id.image_view);
            //mId = itemView.findViewById(R.id.id_view);
            mCardView = itemView.findViewById(R.id.card_view);
        }

    }

}
