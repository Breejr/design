package android.example.com.myapplication.Reviews;

import android.content.Context;
import android.example.com.myapplication.MovieResults;
import android.example.com.myapplication.R;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ReviewAdapter extends RecyclerView.Adapter<ReviewAdapter.ViewHolder> {

    private ArrayList<MovieResults> reviewsArray;
    private Context mContext;



    public ReviewAdapter (Context context, ArrayList<MovieResults> reviewsArray) {
         mContext= context;
        this.reviewsArray = reviewsArray;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.content_review_details, parent, false);
        return new ViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int position) {

        final MovieResults currentItem = reviewsArray.get(position);

        String firstText = currentItem.getAuthor();
        String secondText = currentItem.getReview();

        holder.textView.setText(firstText);
        holder.textView.setText(secondText);


    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }

    @Override
    public int getItemCount() {


        return reviewsArray.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {

        ViewGroup viewGroup = itemView.findViewById(R.id.linear_nested);
        private List<TextView> textViews = new LinkedList<>();
        TextView textView;


        ViewHolder(View itemView) {
            super(itemView);

            for (int i = 0; i<getItemCount(); i++) {
                textView = new TextView(mContext);
                textViews.add(textView);
                viewGroup.addView(textView);
            }


        }
    }




}
