package android.example.com.myapplication.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface MyDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void addFavorites(Movies movies);

    @Query("SELECT * FROM favorites")
    List<Movies> getFavorites();

    @Query("SELECT * FROM favorites")
    LiveData<List<Movies>> getAllFavorites();

    @Delete
    void deleteAll(Movies movies);

}
