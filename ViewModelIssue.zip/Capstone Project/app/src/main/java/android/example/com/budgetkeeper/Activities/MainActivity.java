package android.example.com.budgetkeeper.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.example.com.budgetkeeper.Database.BudgetDao;
import android.example.com.budgetkeeper.Database.BudgetEntry;
import android.example.com.budgetkeeper.Database.BudgetViewModel;
import android.example.com.budgetkeeper.Fragments.MainActivityFragment;
import android.example.com.budgetkeeper.R;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private BudgetDao budgetDao;
    private FragmentManager fragmentManager;
    MainActivityFragment mainActivityFragment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainActivityFragment = new MainActivityFragment();

        //Custom toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Create Fragment

        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.frame_layout_main, MainActivityFragment.newInstance())
                .commit();


    }

    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_items, menu);
        return true;
    }

    public void methodOne(View view) {

        //Click the first button and populate the data below
        String category = "FOOD";
        double amount = 50.00;
        String date = "3/3/3";

        //Send new input to fragment
        Bundle bundle = new Bundle();
        bundle.putString("categoryKey", category);
        bundle.putDouble("amountKey", amount);
        bundle.putString("dateKey", date);

        mainActivityFragment.setArguments(bundle);


    }

}
