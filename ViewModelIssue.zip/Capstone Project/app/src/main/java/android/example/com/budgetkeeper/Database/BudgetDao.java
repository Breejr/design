package android.example.com.budgetkeeper.Database;

import androidx.lifecycle.LiveData;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@androidx.room.Dao
public interface BudgetDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void addBudgetData(BudgetEntry budgetEntry);

    @Query("select * from entry ORDER BY ID")
    LiveData<List<BudgetEntry>> getAllEntries();

    @Delete
    void delete(BudgetEntry budgetEntry);

    @Query("DELETE FROM entry")
    void deleteAllEntries();

}
