package android.example.com.budgetkeeper.Database;

import android.app.Application;
import android.example.com.budgetkeeper.Database.AppDatabase;
import android.example.com.budgetkeeper.Database.BudgetDao;
import android.example.com.budgetkeeper.Database.BudgetEntry;
import android.os.AsyncTask;
import androidx.lifecycle.LiveData;

import java.util.List;

public class BudgetRepository {

    private BudgetDao budgetDao;
    private LiveData<List<BudgetEntry>> allEntries;

    public BudgetRepository(Application application) {

        AppDatabase database = AppDatabase.getDatabase(application);
        budgetDao = database.budgetDao();
        allEntries = budgetDao.getAllEntries();

    }

    public void insert(BudgetEntry budgetEntry) {

        new InsertBudgetAsyncTask(budgetDao).execute(budgetEntry);
    }


    public void delete(BudgetEntry budgetEntry) {

        new DeleteBudgetAsyncTask(budgetDao).execute(budgetEntry);
    }

    public void deleteAllEntries() {

        new DeleteAllEntriesAsyncTask(budgetDao).execute();

    }

    public LiveData<List<BudgetEntry>> getAllEntries() {
     return allEntries;
    }

    private static class InsertBudgetAsyncTask extends AsyncTask<BudgetEntry, Void, Void> {
        private BudgetDao budgetDao;

        private InsertBudgetAsyncTask(BudgetDao budgetDao) {
            this.budgetDao = budgetDao;
        }

        @Override
        protected Void doInBackground(BudgetEntry... budgetEntries) {
            budgetDao.addBudgetData(budgetEntries[0]);
            return null;
        }
    }

    private static class DeleteBudgetAsyncTask extends AsyncTask<BudgetEntry, Void, Void> {
        private BudgetDao budgetDao;

        private DeleteBudgetAsyncTask(BudgetDao budgetDao) {
            this.budgetDao = budgetDao;
        }

        @Override
        protected Void doInBackground(BudgetEntry... budgetEntries) {
            budgetDao.delete(budgetEntries[0]);
            return null;
        }
    }

    private static class DeleteAllEntriesAsyncTask extends AsyncTask<Void, Void, Void> {
        private BudgetDao budgetDao;

        private DeleteAllEntriesAsyncTask(BudgetDao budgetDao) {
            this.budgetDao = budgetDao;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            budgetDao.deleteAllEntries();
            return null;
        }
    }

}

