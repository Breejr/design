package android.example.com.budgetkeeper.Database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;


@Entity(tableName = "entry")
public class BudgetEntry {

@PrimaryKey(autoGenerate = true)
private int id;
private String date;
private double total;
private String category;

    public BudgetEntry(String date, double total, String category) {
        this.date = date;
        this.total = total;
        this.category = category;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }



}
