package android.example.com.budgetkeeper.Database;

import android.app.Application;
import android.example.com.budgetkeeper.Database.BudgetEntry;
import android.example.com.budgetkeeper.Database.BudgetRepository;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;


public class BudgetViewModel extends AndroidViewModel {

    private BudgetRepository budgetRepository;
    private LiveData<List<BudgetEntry>> allEntries;

    public BudgetViewModel(@NonNull Application application) {
        super(application);
        budgetRepository = new BudgetRepository(application);
        allEntries = budgetRepository.getAllEntries();

    }

    public void insert (BudgetEntry budgetEntry) {
        budgetRepository.insert(budgetEntry);
    }

    public void delete (BudgetEntry budgetEntry) {
        budgetRepository.delete(budgetEntry);
    }

    public void deleteAllEntries () {
        budgetRepository.deleteAllEntries();
    }

    public LiveData<List<BudgetEntry>> getAllEntries() {
        return allEntries;
    }
}
