package android.example.com.budgetkeeper.Database;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(entities = {BudgetEntry.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    private static AppDatabase INSTANCE;

    public abstract BudgetDao budgetDao();

    public static synchronized AppDatabase getDatabase(Context context) {
        if (INSTANCE == null) {
            INSTANCE =
                    Room.databaseBuilder(context.getApplicationContext(), AppDatabase.class, "budget_database")

                            .fallbackToDestructiveMigration()
                            .addCallback(roomCallback)
                            .build();
        }
        return INSTANCE;
    }

    private static RoomDatabase.Callback roomCallback = new RoomDatabase.Callback() {

        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            new PopulateDatabaseAsyncTask(INSTANCE).execute();
        }
    };

    private static class PopulateDatabaseAsyncTask extends AsyncTask<Void, Void, Void> {

        private BudgetDao budgetDao;

        private PopulateDatabaseAsyncTask(AppDatabase appDatabase) {
            budgetDao = appDatabase.budgetDao();
        }

        //This is not populating in my recycler view
        @Override
        protected Void doInBackground(Void... voids) {
            Log.e("DO IN BACKGROUND" ,"do inbackground");
            budgetDao.addBudgetData(new BudgetEntry("5/1/20", 5.00, "Clothes"));
            budgetDao.addBudgetData(new BudgetEntry("5/1/12", 10.00, "Food"));
            return null;
        }
    }

}
