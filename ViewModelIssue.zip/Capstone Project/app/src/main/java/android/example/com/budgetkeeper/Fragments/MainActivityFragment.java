package android.example.com.budgetkeeper.Fragments;

import android.example.com.budgetkeeper.Database.BudgetEntry;
import android.example.com.budgetkeeper.Database.BudgetViewModel;
import android.example.com.budgetkeeper.Adapters.EntryAdapter;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.example.com.budgetkeeper.R;
import android.widget.Toast;

import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link MainActivityFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class MainActivityFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match

    private static final String EXTRA_CATEGORY = "android.example.com.budgetkeeper.Fragments.EXTRA_CATEGORY";
    private static final String EXTRA_DATE = "android.example.com.budgetkeeper.Fragments.EXTRA_DATE";
    private static final String EXTRA_AMOUNT = "android.example.com.budgetkeeper.Fragments.EXTRA_AMOUNT";


    // TODO: Rename and change types of parameters

    private RecyclerView recyclerView;
    private String category;
    private double amount;
    private String date;

    BudgetViewModel budgetViewModel;

    public MainActivityFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment MainActivityFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static MainActivityFragment newInstance() {
        MainActivityFragment fragment = new MainActivityFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_main_activity, container, false);


        recyclerView = view.findViewById(R.id.recycler_view_fragment);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setHasFixedSize(true);

        final EntryAdapter entryAdapter = new EntryAdapter();
        recyclerView.setAdapter(entryAdapter);

        budgetViewModel = ViewModelProvider.AndroidViewModelFactory.getInstance(getActivity().getApplication()).create(BudgetViewModel.class);

        //This appears to go off but my recycler view data from the AppDatabase file is not populating
        budgetViewModel.getAllEntries().observe(getActivity(), new Observer<List<BudgetEntry>>() {
            @Override
            public void onChanged(List<BudgetEntry> budgetEntries) {
                //update RecyclerView
                entryAdapter.setEntries(budgetEntries);
                Toast.makeText(getActivity(), "onChanged", Toast.LENGTH_LONG).show();
            }
        });



        return view;

    }

    // This should go off when you click the first button, and it appears to do so but shows BudgetViewModel.insert on a null reference object.
    public void setArguments(Bundle args) {

        category = args.getString("categoryKey");
        //It looks like it's passing over OK
        Log.e("CATEGORY FROM FRAGMENT", category);
        amount = args.getDouble("amountKey");
        date = args.getString("dateKey");

        //Why is this null, it looks like budgetEntry has data in it
        BudgetEntry budgetEntry = new BudgetEntry(date, amount, category);
        //Why is this null, it looks like budgetEntry has data in it
        System.out.println(budgetEntry);
        budgetViewModel.insert(budgetEntry);
        Log.e("Saved", "Entry saved");

    }

}
