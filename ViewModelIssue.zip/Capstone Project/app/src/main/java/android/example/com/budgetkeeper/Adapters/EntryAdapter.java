package android.example.com.budgetkeeper.Adapters;

import android.example.com.budgetkeeper.Database.BudgetEntry;
import android.example.com.budgetkeeper.R;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class EntryAdapter extends RecyclerView.Adapter<EntryAdapter.EntryHolder> {

    private List<BudgetEntry> entries = new ArrayList<>();

    @NonNull
    @Override
    public EntryHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.entries, parent, false);
        return new EntryHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull EntryHolder holder, int position) {

        BudgetEntry currentEntry = entries.get(position);
        holder.textViewCategory.setText(currentEntry.getCategory());
        holder.textViewAmount.setText(String.valueOf(currentEntry.getTotal()));
        holder.textViewDate.setText(currentEntry.getDate());

    }

    public void setEntries(List<BudgetEntry> entries) {
        this.entries = entries;
        notifyDataSetChanged();

    }

    @Override
    public int getItemCount() {
        return entries.size();
    }

    class EntryHolder extends RecyclerView.ViewHolder {
        private TextView textViewCategory;
        private TextView textViewAmount;
        private TextView textViewDate;

        public EntryHolder(@NonNull View itemView) {
            super(itemView);
            textViewCategory = itemView.findViewById(R.id.textview_category);
            textViewAmount = itemView.findViewById(R.id.textview_amount);
            textViewDate = itemView.findViewById(R.id.textview_date);

        }
    }




}
